package com.example.finalproject_nativeandroidapp
package net.androidly.androidlybuttons

import androidx.appcompat.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v4.content.ContextCompat
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import kotlinx.android.synthentic.main.activity_main.*

/*
* The main activity class overrides the oncreate function for app combat activity and view on click listener.
* Using the oncreate function in parenthesis called savedInstanceState.
* Sets the content view for the layout in main activity.
 */
class MainActivity : AppCompatActivity(), View.OnClickListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
/*
*Use the androidly button to apply the linear layoutu params to match parent
*and wrap content for view group. Also, using the text in quotation marks
*called "double the value" to set all caps to be false and keeping the text size to 20f.
 */
        var androidlyButton = Button(this)
        androidlyButton.apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            text = "Double the value"
            setAllCaps(false)
            textSize = 20f
            id = R.id.btnDouble
        }

        androidlyButton.setOnClickListener(this)
        linearlayout.addView(androidlyButton)
/*
* Use the androidly button to apply the linear layout params and view group equal
* to wrap content. The text equal to reset and size to 20f.
* However, the setOnLongCLickListener to text counter.text to equal the 0.toString method
* and put true after the text counter.text.
 */
        androidlyButton = Button(this)
        androidlyButton.apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            text = "RESET"
            textSize = 20f
            setTextColor(ContextCompat.getColor(this@MainActivity, R.color.colorPrimaryDark))
            id = R.id.btnReset
            setOnLongClickListener {
                txtCounter.text = 0.toString()
                true
            }
        }
        androidlyButton.setOnCLickListener(this)
        linearLayout.addView(androidlyButton)
/*
*The override method includes onClick function view in order to put a when statement for view id
* In when statement, I use the double button to put the txtCounter.text along with the toString and
* toInt method to multiply 2 in parenthesis follow by a toString method.
* Use a reset button to put txtCounter.text equal to (-100).toString () method
* before the else statement.
 */
        override fun onClick(v: View?) {
            when (v?.id) {
                R.id.btnDouble -> {
                    txtCounter.text = (txt.Counter.text.toString().toInt() * 2).toString()
                }
                R.id.btnReset -> {
                    txtCounter.text = (-100).toString()
                }
                else -> {
                }
            }
        }
    }
    /*
    *The addOne function puts a view:View for txtCounter.text = (txtCounter.text.toString().
    * toInt() + 1).toString() method.
     */
    fun addOne(view: View) {
        txtCounter.text = (txtCounter.text.toString().toInt() + 1).toString()
    }
}